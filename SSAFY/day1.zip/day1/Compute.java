package SSAFY.day1;

import java.util.*;

public class Compute {
    public static void main(String[] z){
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println(a*b);
        System.out.println((int)a/b);

    }

}
