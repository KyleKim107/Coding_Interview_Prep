package SSAFY.day1;
class CircleArea{
    public static void main(String[] args) {
        double radious = 5*5*3.14;
        System.out.printf("반지름이 5Cm인 원의 없이는 %,.1fCm2입니다", radious );
    }
}